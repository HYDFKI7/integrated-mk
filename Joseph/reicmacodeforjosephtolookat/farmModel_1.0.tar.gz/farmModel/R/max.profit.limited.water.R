max.profit.limited.water<-function(gross.margin.per.ha,crop.water.requirement.ml.per.ha,avail.water){
  library(lpSolveAPI)
  # Linear program 
  # Decision variables are area (ha) for each activity
  lprec<-make.lp(0,length(gross.margin.per.ha))
  # Objective is to maximise gross profit
  set.objfn(lprec, -gross.margin.per.ha)
  # Constraint is to use less than the available water
  add.constraint(lprec,crop.water.requirement.ml.per.ha,"<=",avail.water)
  
  # Solve
  i=solve(lprec)
  if(i!=0) stop("lpSolve return code was not zero")
  
  area=get.variables(lprec)
  names(area)<-names(gross.margin.per.ha)
  
  return(list(
    # Gross value
    gross.value=-get.objective(lprec),
    # Area (ha)
    area=area
    ))
}