max.profit.activities.1yr<-function(CropId,Yields,Prices,CropWaterUse,avail.water,max.land=100){
  
  ## create returns and water use matrix (num activities x num years)
  year <- 1
  nactivity <- max(CropId$activity.id)
  activity.value.per.ha <- rep(0,nactivity)
  activity.water.requirement.ml.per.ha <- rep(0,nactivity)
  ## Add each crop to the activities it contributes to 
  for(i in 1:nrow(CropId)){
    activity.id <- CropId$activity.id[i]
    
    ## For corresponding crop
    crop.id <- CropId$crop.id[i]
    is.irrigated <- CropId$is.irrigated[i]
    
    ## Extract yield for this crop and year
    ## TODO: throw error if combination of crop.id and is.irrigated doesn't exist in Yields
    yield.per.ha <- Yields[Yields$crop.id==crop.id & Yields$is.irrigated==is.irrigated,2+year]
    ## Extract price and variable cost for this crop
    price.per.yield <- Prices$price.per.yield[Prices$crop.id==crop.id]
    variable.cost.per.ha <- Prices$variable.cost.per.ha[Prices$crop.id==crop.id]
    proportion.of.rotation <- CropId$proportion.of.rotation[i]
    
    crop.value.per.ha <- (price.per.yield*yield.per.ha-variable.cost.per.ha)
    activity.value.per.ha[activity.id] <- activity.value.per.ha[activity.id]+
      crop.value.per.ha*proportion.of.rotation
    
    crop.water.requirement.ml.per.ha <- CropWaterUse[crop.id,year]
    
    activity.water.requirement.ml.per.ha[activity.id] <- activity.water.requirement.ml.per.ha[activity.id]+crop.water.requirement.ml.per.ha*proportion.of.rotation
  }

  library(lpSolveAPI)
  lprec<-make.lp(0,nactivity)
  set.objfn(lprec, -activity.value.per.ha)
  add.constraint(lprec,activity.water.requirement.ml.per.ha,"<=",avail.water)
  add.constraint(lprec,rep(1,nactivity),"<=",max.land)
  ## TODO: allow more general constraints. see e.g. https://github.com/josephguillaume/indexCurveUncert/blob/master/R/lp.perf.R
  ## TODO: use set.column, set.constr.type and set.constr.value instead
  st=solve(lprec)
  
  if(st!=0){
    warning(sprintf("lpSolve return code was not zero: %d",st))
  }
  
  list(  
    activity.value.per.ha=activity.value.per.ha,
    activity.water.requirement.ml.per.ha=activity.water.requirement.ml.per.ha,
    activity.value.per.ml=activity.value.per.ha/activity.water.requirement.ml.per.ha,
    gross.value=-get.objective(lprec),
    # Area devoted to each activity (ha)
    area=get.variables(lprec)
  )
}